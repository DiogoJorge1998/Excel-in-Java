import java.util.ArrayList;
import java.util.List;

public class Poligon {

	  private List<Point> pointsList = new ArrayList<Point>();

	  public Poligon(List<Point> l) {
	    for (int i=0; i<l.size(); i++)
	      pointsList.add(new Point(l.get(i).getX(), l.get(i).getY()));
	  }

	  public String getShapeName() {
	    if (pointsList.size() == 3) {
	      return "Triangle";
	    }
	    if (pointsList.size() == 4) {
	      if (isParalel(pointsList.get(0), pointsList.get(1), pointsList.get(2), pointsList.get(3)) 
	        && isParalel(pointsList.get(1), pointsList.get(2), pointsList.get(3), pointsList.get(0))) {
	        if ( (angleBetween(pointsList.get(1), pointsList.get(0), pointsList.get(2))+180)%180 == 90.0
	          && (angleBetween(pointsList.get(2), pointsList.get(1), pointsList.get(3))+180)%180 == 90.0
	          && (angleBetween(pointsList.get(3), pointsList.get(2), pointsList.get(0))+180)%180 == 90.0
	          && (angleBetween(pointsList.get(0), pointsList.get(3), pointsList.get(1))+180)%180 == 90.0) {
	          if (pointsList.get(0).dist(pointsList.get(1)) == pointsList.get(1).dist(pointsList.get(2))) {
	            return "Square";
	          }
	          return "Rectangle";
	        }
	        return "Parallelogram";
	      } 
	      return "Quadrilateral";
	    }
	    return "Poligon";
	  }

	  public int getPerimeter() {
	    double result = 0;
	    for (int i=0; i<pointsList.size(); i++)
	      result += pointsList.get(i).dist(pointsList.get((i+1)%pointsList.size()));
	    return (int) result;
	  }

	  private boolean isParalel (Point a, Point b, Point c, Point d) {
	    int x1 = a.getX();
	    int y1 = a.getY();
	    int x2 = b.getX();
	    int y2 = b.getY();
	    int x3 = c.getX();
	    int y3 = c.getY();
	    int x4 = d.getX();
	    int y4 = d.getY();
	    float D = (x1-x2)*(y3-y4) - (y1-y2)*(x3-x4);
	    //println(D);
	    //paralelo
	    if (D == 0) {
	      return true;
	    } 
	    return false;
	  }

	  private double angleBetween(Point c, Point a, Point b) {
	    return Math.toDegrees(Math.atan2(a.getX() - c.getX(), a.getY() - c.getY()) - Math.atan2(b.getX() - c.getX(), b.getY() - c.getY()));
	  }
}
