import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class JUnitTriangleMesh {

	@Test
	public void testHullSize() {
		TriangleMesh m;
		
		Point[] a0 = {new Point(3, 3), new Point(3, 2), new Point(1, 1), new Point(5, 1)}; //Triangle 9
		m = new TriangleMesh(a0);
		assertEquals(m.getHull().size(), 3);
		
		Point[] a1 = {new Point(2, 3), new Point(1, 2), new Point(3, 2), new Point(2, 1), new Point(2,2)}; //Square 5
		m = new TriangleMesh(a1);
		assertEquals(m.getHull().size(), 4);
		
		Point[] a2 = {new Point(3, 6), new Point(3, 0), new Point(5, 3), new Point(1, 3)}; //Parelelogram 14
		m = new TriangleMesh(a2);
		assertEquals(m.getHull().size(), 4);
		
		Point[] a3 = {new Point(0,0), new Point(1,0), new Point(2, 0), new Point(1, 1)}; // Triangle 4
		m = new TriangleMesh(a3);
		assertEquals(m.getHull().size(), 3);

		Point[] a4 = {new Point(2, 3), new Point(1, 2), new Point(3, 2), new Point(2, 1), new Point(3, 3), new Point(6, 0)}; // Poligon 12
		m = new TriangleMesh(a4);
		assertEquals(m.getHull().size(), 5);		
	}
	
	
	@Test
	public void testShapeName() {
		TriangleMesh m;
		Poligon p;
		
		Point[] a0 = {new Point(3, 3), new Point(3, 2), new Point(1, 1), new Point(5, 1)}; //Triangle 9
		m = new TriangleMesh(a0);
		p = new Poligon(m.getHull());
		assertEquals(p.getShapeName(), "Triangle");
		
		Point[] a1 = {new Point(3, 6), new Point(3, 0), new Point(5, 3), new Point(0, 3)}; //Quadrilateral 15
		m = new TriangleMesh(a1);
		p = new Poligon(m.getHull());
		assertEquals(p.getShapeName(), "Quadrilateral");
		
		Point[] a2 = {new Point(3, 6), new Point(3, 0), new Point(5, 3), new Point(1, 3)}; //Parallelogram 14
		m = new TriangleMesh(a2);
		p = new Poligon(m.getHull());
		assertEquals(p.getShapeName(), "Parallelogram");
		
		Point[] a3 = {new Point(3, 8), new Point(1, 6), new Point(7, 4), new Point(5, 2)}; //Rectangle 16
		m = new TriangleMesh(a3);
		p = new Poligon(m.getHull());
		assertEquals(p.getShapeName(), "Rectangle");
		
		Point[] a4 = {new Point(2, 3), new Point(1, 2), new Point(3, 2), new Point(2, 1), new Point(2,2)}; //Square 5
		m = new TriangleMesh(a4);
		p = new Poligon(m.getHull());
		assertEquals(p.getShapeName(), "Square");
		
		Point[] a5 = {new Point(2, 3), new Point(1, 2), new Point(3, 2), new Point(2, 1), new Point(3, 3), new Point(6, 0)}; // Poligon 12
		m = new TriangleMesh(a5);
		p = new Poligon(m.getHull());
		assertEquals(p.getShapeName(), "Poligon");
		
		Point[] a6 = {new Point(0,0), new Point(1,0), new Point(2, 0), new Point(1, 1)}; // Triangle 4
		m = new TriangleMesh(a6);
		p = new Poligon(m.getHull());
		assertEquals(p.getShapeName(), "Triangle");
	}
	
	@Test
	public void testPerimeter() {
		TriangleMesh m;
		Poligon p;
		
		Point[] a0 = {new Point(3, 3), new Point(3, 2), new Point(1, 1), new Point(5, 1)}; //Triangle 9
		m = new TriangleMesh(a0);
		p = new Poligon(m.getHull());
		assertEquals(p.getPerimeter(), 9);
		
		Point[] a1 = {new Point(3, 6), new Point(3, 0), new Point(5, 3), new Point(0, 3)}; //Quadrilateral 15
		m = new TriangleMesh(a1);
		p = new Poligon(m.getHull());
		assertEquals(p.getPerimeter(), 15);
		
		Point[] a2 = {new Point(3, 6), new Point(3, 0), new Point(5, 3), new Point(1, 3)}; //Parallelogram 14
		m = new TriangleMesh(a2);
		p = new Poligon(m.getHull());
		assertEquals(p.getPerimeter(), 14);
		
		Point[] a3 = {new Point(3, 8), new Point(1, 6), new Point(7, 4), new Point(5, 2)}; //Rectangle 16
		m = new TriangleMesh(a3);
		p = new Poligon(m.getHull());
		assertEquals(p.getPerimeter(), 16);
		
		Point[] a4 = {new Point(2, 3), new Point(1, 2), new Point(3, 2), new Point(2, 1), new Point(2,2)}; //Square 5
		m = new TriangleMesh(a4);
		p = new Poligon(m.getHull());
		assertEquals(p.getPerimeter(), 5);
		
		Point[] a5 = {new Point(2, 3), new Point(1, 2), new Point(3, 2), new Point(2, 1), new Point(3, 3), new Point(6, 0)}; // Poligon 12
		m = new TriangleMesh(a5);
		p = new Poligon(m.getHull());
		assertEquals(p.getPerimeter(), 12);
		
		Point[] a6 = {new Point(0,0), new Point(1,0), new Point(2, 0), new Point(1, 1)}; // Triangle 4
		m = new TriangleMesh(a6);
		p = new Poligon(m.getHull());
		assertEquals(p.getPerimeter(), 4);
	}
}
