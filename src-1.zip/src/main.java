import java.util.Scanner;

public class main {

	public static void main (String [] args) {
	    
	    Scanner scan = new Scanner(System.in);
	    int x = scan.nextInt();
	    Point[] a = new Point[x];
	    
	    for (int i=0; i < x; i++){	    
	    	a[i] = new Point(scan.nextInt(),scan.nextInt());
	    }
	    scan.close();
	    
	    TriangleMesh Mesh = new TriangleMesh(a);
	    Poligon Poli = new Poligon(Mesh.getHull());
	    
	    System.out.println(Poli.getShapeName()+" "+Poli.getPerimeter());
	}
}