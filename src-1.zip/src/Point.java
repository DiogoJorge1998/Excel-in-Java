public class Point {
	  private int x, y;

	  public Point(int x, int y) {
	    setX(x);
	    setY(y);
	  }
	  public int getX() {
	    return x;
	  }
	  public int getY() {
	    return y;
	  }
	  public void setX(int i) {
	    if (i>=0)
	      x = i;
	    else
	      System.exit(1);
	  }
	  public void setY(int i) {
	    if (i>=0)
	      y = i;
	    else
	      System.exit(1);
	  }
	  public double dist (Point p) {
	    double dx = getX() - p.getX();
	    double dy = getY() - p.getY();
	    return Math.sqrt(dx*dx + dy*dy);
	  }
	}